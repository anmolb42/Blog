function convertusdTocad(){
    var usdIn = parseFloat(document.getElementById('usdOut').value);
    if(isNaN(usdIn)) {
        alert("Invalid Input")
        return;
    }
    var exchangeRate = 1.359;
    var cadOut = usdIn * exchangeRate;
    document.getElementById('cadOut').value = cadOut.toFixed(3);
    
}

function convertcadTousd(){
    var cadIn = parseFloat(document.getElementById('cadOut').value);
    if(isNaN(cadIn)) {
        alert("Invalid Input")
        return;
    }
    var exchangeRate = 0.736;
    var usdOut = cadIn * exchangeRate;
    document.getElementById('usdOut').value = usdOut.toFixed(3);
    
}